# Aria — COD Coaching Discord Bot (V1)

A minimal, deploy-ready bot that:
- Serves a study guide via slash commands (/guide, /guide_topics).
- Auto-scaffolds your server structure and roles (/setup_server).
- Mobile-friendly deployment via Replit or Railway (works from iPhone).

---

QUICK START (NO PC)

Option A) Replit (mobile-friendly)
  1) Create a new Python Repl.
  2) Upload the contents of this zip (or paste the files).
  3) In Replit Secrets, add:
     - DISCORD_TOKEN = your bot token
     - OWNER_ID = your Discord user ID (numbers)
  4) Click Run. Keep the tab open, or use Replit Deployments for always-on.

Option B) Railway (always-on)
  1) Push this folder to a GitHub repo (can be done from phone apps or GitHub mobile).
  2) On railway.app → New Project → Deploy from GitHub.
  3) Add Environment Variables:
     - DISCORD_TOKEN
     - OWNER_ID
  4) Deploy. Logs will show "Synced global commands" when ready.

INVITE THE BOT
  - In the Discord Developer Portal → OAuth2 → URL Generator:
    Scopes: bot, applications.commands
    Bot Permissions: Administrator (you can reduce later)
  - Open the generated URL on your phone to invite the bot.

COMMANDS
  - /ping — Health check.
  - /guide topic:<string> — Returns study guide content (aiming, movement, comms, discipline).
  - /guide_topics — Lists available topics.
  - /setup_server — Owner-only server scaffolding (roles + categories + text channels).

CUSTOMIZE STUDY GUIDE
  Edit data/study_guide.yml and redeploy (Railway) or just save (Replit).

NOTES
  - Set GUILD_ID (optional) to your server ID to register commands instantly for testing.
  - Keep your token secret. Never commit .env.
