#!/usr/bin/env python3
import os
import asyncio
import logging
from typing import Optional
import discord
from discord.ext import commands

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("aria")

TOKEN = os.getenv("DISCORD_TOKEN")
OWNER_ID = int(os.getenv("OWNER_ID", "0"))
DEFAULT_GUILD_ID = int(os.getenv("GUILD_ID", "0"))

intents = discord.Intents.default()
intents.message_content = False
intents.members = True
intents.guilds = True

bot = commands.Bot(command_prefix="!", intents=intents)

@bot.event
async def on_ready():
    logger.info(f"Logged in as {bot.user} (id: {bot.user.id})")
    try:
        if DEFAULT_GUILD_ID:
            guild = discord.Object(id=DEFAULT_GUILD_ID)
            await bot.tree.sync(guild=guild)
            logger.info(f"Synced commands to guild {DEFAULT_GUILD_ID}")
        else:
            await bot.tree.sync()
            logger.info("Synced global commands")
    except Exception as e:
        logger.exception("Failed to sync commands: %s", e)

@bot.tree.command(name="ping", description="Check if Aria is alive")
async def ping(interaction: discord.Interaction):
    await interaction.response.send_message("Pong! ✅", ephemeral=True)

async def load_cogs():
    await bot.load_extension("cogs.guide")
    await bot.load_extension("cogs.setup_server")

async def main():
    async with bot:
        await load_cogs()
        await bot.start(TOKEN)

if __name__ == "__main__":
    if not TOKEN:
        raise SystemExit("DISCORD_TOKEN not set. See README.md for setup.")
    asyncio.run(main())
