import discord
from discord import app_commands
from discord.ext import commands
import yaml
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "study_guide.yml"

class Guide(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot
        self._cache = None

    def load_content(self):
        if self._cache is None:
            with open(DATA_PATH, "r", encoding="utf-8") as f:
                self._cache = yaml.safe_load(f) or {}
        return self._cache

    @app_commands.command(name="guide", description="Get study guide content by topic (e.g., 'aiming', 'movement').")
    @app_commands.describe(topic="Study topic to retrieve")
    async def guide(self, interaction: discord.Interaction, topic: str):
        content = self.load_content()
        topic_key = topic.strip().lower()
        entry = content.get("topics", {}).get(topic_key)
        if not entry:
            available = ", ".join(sorted(content.get("topics", {}).keys()))
            await interaction.response.send_message(
                f"❌ Topic not found. Try one of: {available}", ephemeral=True
            )
            return

        embed = discord.Embed(title=f"Study Guide: {entry.get('title', topic.title())}")
        notes = entry.get("summary")
        if notes:
            embed.description = notes[:4000]

        bullets = entry.get("bullets") or []
        for b in bullets[:20]:
            embed.add_field(name="•", value=str(b)[:1024], inline=False)

        await interaction.response.send_message(embed=embed, ephemeral=True)

    @app_commands.command(name="guide_topics", description="List all available study topics.")
    async def guide_topics(self, interaction: discord.Interaction):
        content = self.load_content()
        topics = sorted(content.get("topics", {}).keys())
        if not topics:
            await interaction.response.send_message("No topics available yet.", ephemeral=True)
            return
        msg = "\n".join(f"- {t}" for t in topics)
        await interaction.response.send_message(f"**Available Topics**\n{msg}", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(Guide(bot))
