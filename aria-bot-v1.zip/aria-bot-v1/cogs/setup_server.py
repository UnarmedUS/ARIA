import discord
from discord import app_commands
from discord.ext import commands
import os

OWNER_ID = int(os.getenv("OWNER_ID", "0"))

CATEGORIES = [
    ("WELCOME & INFO", ["#rules", "#announcements", "#faq"]),
    ("COACHING", ["#coaching-requests", "#session-schedule", "#vod-reviews"]),
    ("TRAINING", ["#aim-drills", "#movement-drills", "#strategy-lab"]),
    ("TEAM", ["#scrim-planning", "#comms-review", "#match-recaps"]),
    ("OFF-TOPIC", ["#lounge"]),
]

ROLES = [
    ("Owner", {"permissions": discord.Permissions.all(), "hoist": True, "mentionable": False, "color": discord.Color.red()}),
    ("Coach", {"permissions": discord.Permissions(manage_messages=True, mute_members=True), "hoist": True, "mentionable": True}),
    ("Player", {"permissions": discord.Permissions(send_messages=True), "hoist": False, "mentionable": True}),
    ("Outsource A", {"permissions": discord.Permissions(view_audit_log=True, manage_messages=True), "hoist": True, "mentionable": True}),
    ("Outsource B", {"permissions": discord.Permissions(view_audit_log=True), "hoist": True, "mentionable": True}),
]

class SetupServer(commands.Cog):
    def __init__(self, bot: commands.Bot):
        self.bot = bot

    @app_commands.checks.has_permissions(administrator=True)
    @app_commands.command(name="setup_server", description="Auto-create channels, categories, and baseline roles.")
    async def setup_server(self, interaction: discord.Interaction):
        if interaction.user.id != OWNER_ID:
            await interaction.response.send_message("❌ Only the Owner can run this.", ephemeral=True)
            return

        await interaction.response.defer(ephemeral=True, thinking=True)

        guild = interaction.guild
        if guild is None:
            await interaction.followup.send("This command must be used in a server.", ephemeral=True)
            return

        created_roles = {}
        for role_name, kwargs in ROLES:
            role = discord.utils.get(guild.roles, name=role_name)
            if role is None:
                role = await guild.create_role(name=role_name, **kwargs)
            created_roles[role_name] = role

        try:
            owner_role = created_roles.get("Owner") or discord.utils.get(guild.roles, name="Owner")
            if owner_role:
                await guild.edit_role_positions(positions={owner_role: len(guild.roles)-1})
        except Exception:
            pass

        for cat_name, channels in CATEGORIES:
            category = discord.utils.get(guild.categories, name=cat_name)
            if category is None:
                category = await guild.create_category(cat_name)
            for ch_name in channels:
                name = ch_name[1:] if ch_name.startswith("#") else ch_name
                if not discord.utils.get(category.channels, name=name):
                    await category.create_text_channel(name)

        await interaction.followup.send("✅ Server scaffolding complete.", ephemeral=True)

async def setup(bot: commands.Bot):
    await bot.add_cog(SetupServer(bot))
